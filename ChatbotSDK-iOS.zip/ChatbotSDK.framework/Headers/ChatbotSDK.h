//
//  ChatbotSDK.h
//  ChatbotSDK
//
//  Created by Pawel Zebrowski on 2018-11-05.
//  Copyright © 2018 InContext.ai. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ChatbotSDK.
FOUNDATION_EXPORT double ChatbotSDKVersionNumber;

//! Project version string for ChatbotSDK.
FOUNDATION_EXPORT const unsigned char ChatbotSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChatbotSDK/PublicHeader.h>


